export interface License {
    usersCount(): number;
    extractionAllowed(): boolean
}