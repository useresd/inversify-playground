export interface UserInfo {
    id: string,
    email: string,
    fullName: string,
    organizationId: string
}