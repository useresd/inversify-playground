export interface TenantDetails {
    id: string,
    name: string
}