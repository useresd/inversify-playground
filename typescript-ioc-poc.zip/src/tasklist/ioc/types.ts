export const TYPES = {
    CustomerService: Symbol.for("CustomerService"),
    CustomerRepository: Symbol.for("CustomerRepository")
}